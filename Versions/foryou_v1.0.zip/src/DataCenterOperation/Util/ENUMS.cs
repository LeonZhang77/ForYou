﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataCenterOperation.Util
{
    public class ENUMS
    {
        public enum Type
        {
            FixedAssertNumber
        };
    }
}
