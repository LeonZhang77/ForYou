Store Failers Reports in this folder.
