This folder is created for DB backup files.
